This directory contains some simple examples of the use of BIO's
to simplify socket programming.

The client-conf, server-conf, client-arg and client-conf include examples
of how to use the SSL_CONF API for configuration file or command line
processing.
